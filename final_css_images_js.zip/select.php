<html><head><title>Tacos</title></head>
<body>
<table border=1>
<tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Visit Again?</th></tr>
<?php
include 'db.inc.php';
if(!($connection=@mysql_connect($hostName,$username, $password)))
	showerror();
if(!mysql_select_db($databaseName,$connection))
	showerror();

$query="SELECT * FROM customers";
if(!($result=@mysql_query($query,$connection)))
	showerror();

while($row=@mysql_fetch_array($result))
	echo "<tr><td>{$row["id"]}</td>
<td>{$row["fname"]}</td>
<td>{$row["lname"]}</td>
<td>{$row["visitagain"]}</td></tr>";
?>

</table></body>
</html>