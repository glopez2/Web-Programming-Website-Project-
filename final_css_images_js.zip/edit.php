<?php

function renderForm($id, $fname, $lname, $error)
{
?>
<html>
<head>
<title>Edit Record</title>
</head>
<body>
<?php

// if there are any errors, display them
if ($error != '')
{
echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
}

?>


<form action="" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>"/>
<div>
<p><strong>ID:</strong> <?php echo $id; ?></p>
<strong>First Name: *</strong> <input type="text" name="fname" value="<?php echo $fname; ?>"/><br/>
<strong>Last Name: *</strong> <input type="text" name="lname" value="<?php echo $lname; ?>"/><br/>
<p>* Required</p>
<input type="submit" name="submit" value="Submit">
</div>
</form>
</body>
</html>
<?php

}
// connect to the database

include('db.inc.php');


if (isset($_POST['submit']))
{
if (is_numeric($_POST['id']))
{

$id = $_POST['id'];
$fname = mysql_real_escape_string(htmlspecialchars($_POST['fname']));
$lname = mysql_real_escape_string(htmlspecialchars($_POST['lname']));

// check that firstname/lastname fields are both filled in

if ($fname == '' || $lname == '')

{

// generate error message

$error = 'ERROR: Please fill in all required fields!';



//error, display form

renderForm($id, $fname, $lname, $error);

}

else

{

// save the data to the database

mysql_query("UPDATE customers SET fname='$fname', lname='$lname' WHERE id='$id'")
or die(mysql_error());


header("Location: view.php");
}
}
else
{

echo 'Error!';

}
}

else

{

if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)
{


$id = $_GET['id'];
$result = mysql_query("SELECT * FROM customers WHERE id=$id")
or die(mysql_error());
$row = mysql_fetch_array($result);



// check that the 'id' matches up with a row in the databse

if($row)

{



// get data from db

$fname = $row['fname'];
$lname = $row['lname'];


renderForm($id, $fname, $lname, '');
}

else

{
echo "No results!";
}
}
else
{
echo 'Error!';
}
}
?>