<html>
<body>
Welcome <?php echo $_GET["name"]; ?><br>
Email address is:<?php echo $_GET["email"]; ?><br>
This is your message:<?php echo $_GET["message"]; ?><br>

</body>
</html>