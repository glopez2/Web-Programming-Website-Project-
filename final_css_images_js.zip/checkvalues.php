<html>
<head>
<Title>Simple PHP check</Title>
<meta charset="utf-8">
</head>
<body>
<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$visitagain = $_POST['visitagain'];
if(!(empty($fname)) && !(empty($lname)))
{
	echo"submission complete";
	echo'<br />';
	echo "first name value";
	echo"flname";
	echo'<br/>';
	echo "last name value";
	echo"$lname";
}
if ((empty($fname)) && (empty($lname)))
{
	echo"first name not entered";
	echo '<br />';
	echo"last name not entered";
	echo'<br />';
}

?>
</body>
</html>