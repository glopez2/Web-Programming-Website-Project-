<html><head><title>Pizza</title></head>
<body>

<form action="delete.php" method="post">
	Delete Record</br>
	ID:
	<input name="id" type="text" />
	<input name="Submit" type="submit" value="delete record" />
</form>


<?php
include 'db.inc.php';
// Connect to MySQL DBMS
if (!($connection = @ mysql_connect($hostName, $username,
  $password)))
  showerror();
// Use the recipes database
if (!mysql_select_db($databaseName, $connection))
  showerror();
 $id = $_POST['id'];
// Create SQL statement
$query = "DELETE FROM customers WHERE id = '".$id."'";
// Execute SQL statement
if (!($result = @ mysql_query ($query, $connection)))
  showerror();
// Display results
else
  echo "Deleted";
?>

<p align=center><a href="select.php">VIEW RECORDS</a></p>
<p align=center><a href="database.html">HOME</a></p>
</body>
</html>