<html><head><title>Tacos</title></head>
<body>
<table border=1>
<tr><th>ID</th><th>Meat</th><th>Shell</th><th>Salsa</th><th>Topping</th><th>Price</th><tr>
<?php
include 'db.inc.php';
if(!($connection=@mysql_connect($hostName,$username, $password)))
	showerror();
if(!mysql_select_db($databaseName,$connection))
	showerror();

$query="SELECT * FROM tacos";
if(!($result=@mysql_query($query,$connection)))
	showerror();

while($row=@mysql_fetch_array($result))
	echo "<tr><td>{$row["id"]}</td>
<td>{$row["meat"]}</td>
<td>{$row["shell"]}</td>
<td>{$row["salsa"]}</td>
<td>{$row["topping"]}</td>
<td>{$row["price"]}</td></tr>";
?>

</table></body>
</html>