<?php
//Sample Database Connection Syntax for PHP and MySQL.

//Connect To Database

$hostname="localhost:/usr/cis/var/triton.sock";
$username="glopez2";
$password="Cosc*fp9e";
$dbname="glopez2db";
$usertable="tacos";
$yourfield = "meat";

mysql_connect($hostname,$username, $password) or die ("<html><script language='JavaScript'>alert('Unable to connect to database! Please try again later.'),history.go(-1)</script></html>");
mysql_select_db($dbname);

# Check If Record Exists

$query = "SELECT * FROM $usertable";

$result = mysql_query($query);

if($result)
{
  while($row = mysql_fetch_array($result))
  {
    $name = $row["$yourfield"];
    echo "Name: ".$name."<br/>";
  }
}
?>