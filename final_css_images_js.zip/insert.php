<html><head><title>Pizza</title></head>
<body>

	<form action="insert.php" method="post">
	Add Your Customers</br>
	Name:<input type="text" name="type"></br>
	Last Name: <input type="text" name="type"></br>
	Would you return?:<input type="text" name="visitagain"></br>
	<input type="submit" value="Insert Values">
	</form>

<?php
include 'db.inc.php';
// Connect to MySQL DBMS
if (!($connection = @ mysql_connect($hostName, $username,
  $password)))
  showerror();
// Use the cars database
if (!mysql_select_db($databaseName, $connection))
  showerror();
 
// Create SQL statement
$query = "INSERT INTO customers(fname, lname, visitagain) VALUES('$_POST[fname]','$_POST[lname]','$_POST[visitagain]')";
// Execute SQL statement
if (!($result = @ mysql_query ($query, $connection)))
  showerror();
// Display results
else
  echo "Your Recipe has been recorded";
?>

<p align=center><a href="select.php">VIEW RECORDS</a></p>
<p align=center><a href="database.html">HOME</a></p>
</body>
</html>
