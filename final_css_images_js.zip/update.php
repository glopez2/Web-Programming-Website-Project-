<html><head><title>Customers</title></head>
<body>

<form action="update.php" method="post">
			Update Record</br>
			ID:<input type="text" name="id" /></br>
			First Name:<input type="text" name="fname" /></br>
			Last Name:<input type="text" name="lname" /></br>
			Visit again:<input type="text" name="visitagain" /></br>
			<input type="submit" name="Submit" value="update" /></br>
			</form>

<?php
include 'db.inc.php';
// Connect to MySQL DBMS
if (!($connection = @ mysql_connect($hostName, $username,
  $password)))
  showerror();
// Use the recipes database
if (!mysql_select_db($databaseName, $connection))
  showerror();
$id = $_POST['id'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$visitagain = $_POST['visitagain'];
// Create SQL statement
$query = "UPDATE customers SET fname = '$fname',lname = '$lname',visitagain = '$visitagain' WHERE id = '$id'";

// Execute SQL statement
if (!($result = @ mysql_query ($query, $connection)))
  showerror();
// Display results
else
  echo "Record updated";
?>


<p align=center><a href="select.php">VIEW RECORDS</a></p>
<p align=center><a href="database.html">HOME</a></p>
</body>
</html>