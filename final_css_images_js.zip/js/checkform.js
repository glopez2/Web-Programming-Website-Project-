function validate() {
	if(title.value=="") {
		alert("title is back - please enter title");
		document.getElementById("title").focus();
		document.getElementById("title").style.backgroundColor="#E1411E";
		return false;
	}
	
	else {
		document.getElementById("title").style.backgroundColor="#FFFFFF";
		return true;
	}

}