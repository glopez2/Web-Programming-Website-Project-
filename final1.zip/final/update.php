<html>
<body>
<?php
$server="localhost:/usr/cis/var/triton.sock";
$username="glopez2db";
$password="Cosc*fp9e";
$connect_mysql=mysql_connect($server,$username,$password) or die ("Connection Failed!");
$mysql_db=mysql_select_db("glopez2db",$connect_mysql) or die ("Could not Connect to Database");
$query = "SELECT * FROM tacos";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
$i=0;
while($rows=mysql_fetch_array($result))
{
$roll[$i]=$rows['person'];
$i++;
}
$total_elmt=count($roll);
?>
<form method="POST" action="">
Select the person to Update: <select name="sel">
<option>Select</option>
<?php 
for($j=0;$j<$total_elmt;$j++)
{
?><option><?php 
echo $roll[$j];
?></option><?php
}
?>
</select><br />
Name: <input name="person" type="text" /><br />
Tacos: <input name="tacos" type="text" /><br />
<input name="submit" type="submit" value="Update"/><br />
<input name="reset" type="reset" value="Reset"/>
</form>

<?php

if(isset($_POST['submit']))
{
$value=$_POST['sel'];
$person=$_POST['person'];
$tacos=$_POST['tacos'];

$query2 = "UPDATE tacos SET person='$person',tacos='$tacos' WHERE person='$value'";
$result2=mysql_query($query2) or die("Query Failed : ".mysql_error());
echo "Successfully Updated";
}
?>
<p align=right><a href="view.php">VIEW RECORDS</a></p>
<p align=right><a href="database.html">HOME</a></p>