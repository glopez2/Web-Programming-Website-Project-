<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert form</title>
<link type="text/css" media="all" rel="stylesheet" href="style.css">
</head>

<body>
<div class="display">
<form action="insert.php" method="post" name="insertform">
<p>
  <label for="name" id="preinput"> Name : </label>
  <input type="text" name="username" required placeholder="Enter your name" id="inputid"/>
</p>
<p>
  <label  for="type" id="preinput"> Type : </label>
  <input type="text" name="type" required placeholder="Enter your taco choice" id="inputid" />
</p>
<p>
  <label for="amount" id="preinput"> Amount of tacos : </label>
  <input type="text" name="amount" required placeholder="Enter your total tacos" id="inputid" />
</p>
<p>
  <input type="submit" name="send" value="Submit" id="inputid1"  />
</p>
</form>
</div>
<?php include('view.php'); ?>
</body>
</html>