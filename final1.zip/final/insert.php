<html>
<body>
<form method="POST" action="">
Name: <input name="person" type="text" /><br />
Tacos: <input name="tacos" type="text" /><br />
<input name="submit" type="submit" value="Insert"/><br />
<input name="reset" type="reset" value="Reset"/>
</form>

<?php
if(isset($_POST['submit']))
{
$person=$_POST['person'];
$tacos=$_POST['tacos'];

$server="localhost:/usr/cis/var/triton.sock";
$username="glopez2db";
$password="Cosc*fp9e";
$connect_mysql=mysql_connect($server,$username,$password) or die ("Connection Failed!");
$mysql_db=mysql_select_db("glopez2db",$connect_mysql) or die ("Could not Connect to Database");
$query = "INSERT INTO orders VALUES (null,'$person','$tacos')";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
$message="Order Details Successfully Added";
echo $message;
mysql_close($connect_mysql);


}
?>


<p align=right><a href="view.php">VIEW RECORDS</a></p>
<p align=right><a href="database.html">HOME</a></p>